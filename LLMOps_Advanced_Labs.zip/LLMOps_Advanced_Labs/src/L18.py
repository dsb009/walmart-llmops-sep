# %% [markdown]
# # L18 — Containerisation and Kubernetes: package, deploy with GPU scheduling, roll out with zero failed requests
# **Objective 11.**
#
# **Northfield Grocers context:** the customer assistant's serving stack (vLLM + the guardrailed FastAPI app) must run on the AKS GPU node pool, be upgraded from model version v3 to v4 during trading hours, and drop **zero** customer requests while doing it. Platform engineering owns the Dockerfile, the Kubernetes manifests with GPU scheduling, and the proof that a rolling update is lossless.
#
# **Retail use cases:** upgrading the assistant model on a Saturday without a maintenance window; running the extraction batch job on the same GPU pool with resource limits; keeping two replicas alive through node maintenance.
#
# **Platform:** any for Steps 1–4 (SMOKE builds and validates the artefacts and simulates the rollout in-process); a Kubernetes cluster with GPU nodes (AKS + NVIDIA device plugin) for Step 5.
#
# **Done means:** Dockerfile and manifests generated and validated (GPU resource request, readiness probe, rolling-update strategy); rollout simulation serves 100% of requests during a v3→v4 replacement; a bad v4 (failing readiness) is never sent traffic.
#
# ## Step 1 — Package the serving stack: the Dockerfile
# *Why:* a container fixes the CUDA/torch/vLLM versions once (the version-drift problem from every earlier lab). Base image from the framework vendor, pinned requirements, a non-root user, and a healthcheck.
# %%
DOCKERFILE = """FROM vllm/vllm-openai:latest          # pin a tag in production, e.g. :v0.x.y
WORKDIR /app
COPY requirements-serving.txt .
RUN pip install --no-cache-dir -r requirements-serving.txt   # fastapi, httpx, pydantic, guardrail deps
COPY app/ ./app/
ENV MODEL_ID=google/gemma-4-e4b-it MODEL_VERSION=v3 PORT=8000
EXPOSE 8000
HEALTHCHECK --interval=30s --timeout=5s --start-period=180s CMD curl -f http://localhost:8000/health || exit 1
USER 1000
ENTRYPOINT ["python", "-m", "app.serve"]
"""
os.makedirs("/tmp/l18", exist_ok=True); open("/tmp/l18/Dockerfile", "w").write(DOCKERFILE)
def lint_dockerfile(text):
    """Minimal checks the platform team enforces: pinned base tag, non-root USER, HEALTHCHECK, EXPOSE."""
    # >>> SOLUTION return dict of check -> bool
    return {"has_user": bool(re.search(r"^USER\s+\S+", text, re.M)), "has_healthcheck": "HEALTHCHECK" in text,
            "has_expose": "EXPOSE" in text, "pinned_base": not re.search(r"^FROM\s+\S+:latest", text, re.M)}
    # <<< SOLUTION
lint = lint_dockerfile(DOCKERFILE); print(lint)
check(lint["has_user"] and lint["has_healthcheck"] and lint["has_expose"], "Dockerfile has non-root user, healthcheck and exposed port")
print("Note: pinned_base =", lint["pinned_base"], "→ the ':latest' tag is a planted defect; pin it before production.")

# %% [markdown]
# ## Step 2 — Kubernetes manifests with GPU scheduling
# *Why:* GPUs are scheduled through the NVIDIA device plugin as an extended resource `nvidia.com/gpu`. A Deployment with `replicas: 2`, a readiness probe that only passes once the model is loaded, and a RollingUpdate strategy with `maxUnavailable: 0` is what makes upgrades lossless.
# %%
ensure_packages(["pyyaml"]); import yaml
def deployment_manifest(version, image_tag, replicas=2):
    # >>> SOLUTION build the dict: Deployment with GPU limit 1, readiness/liveness probes on /health, RollingUpdate maxSurge 1 maxUnavailable 0, nodeSelector for the GPU pool
    return {"apiVersion": "apps/v1", "kind": "Deployment",
            "metadata": {"name": "assistant-serving", "labels": {"app": "assistant", "model_version": version}},
            "spec": {"replicas": replicas, "selector": {"matchLabels": {"app": "assistant"}},
                     "strategy": {"type": "RollingUpdate", "rollingUpdate": {"maxSurge": 1, "maxUnavailable": 0}},
                     "template": {"metadata": {"labels": {"app": "assistant", "model_version": version}},
                                  "spec": {"nodeSelector": {"agentpool": "gpupool"},
                                           "tolerations": [{"key": "nvidia.com/gpu", "operator": "Exists", "effect": "NoSchedule"}],
                                           "containers": [{"name": "serving", "image": f"northfieldacr.azurecr.io/assistant:{image_tag}",
                                                           "ports": [{"containerPort": 8000}],
                                                           "env": [{"name": "MODEL_VERSION", "value": version}],
                                                           "resources": {"limits": {"nvidia.com/gpu": 1, "memory": "64Gi"}, "requests": {"cpu": "4", "memory": "32Gi"}},
                                                           "readinessProbe": {"httpGet": {"path": "/health", "port": 8000}, "initialDelaySeconds": 60, "periodSeconds": 10, "failureThreshold": 30},
                                                           "livenessProbe": {"httpGet": {"path": "/health", "port": 8000}, "initialDelaySeconds": 300, "periodSeconds": 30}}]}}}}
    # <<< SOLUTION
service = {"apiVersion": "v1", "kind": "Service", "metadata": {"name": "assistant"}, "spec": {"selector": {"app": "assistant"}, "ports": [{"port": 80, "targetPort": 8000}]}}
hpa = {"apiVersion": "autoscaling/v2", "kind": "HorizontalPodAutoscaler", "metadata": {"name": "assistant-hpa"},
       "spec": {"scaleTargetRef": {"apiVersion": "apps/v1", "kind": "Deployment", "name": "assistant-serving"}, "minReplicas": 2, "maxReplicas": 8,
                "metrics": [{"type": "Pods", "pods": {"metric": {"name": "vllm_num_requests_waiting"}, "target": {"type": "AverageValue", "averageValue": "8"}}}]}}
dep_v3 = deployment_manifest("v3", "v3.0.1"); dep_v4 = deployment_manifest("v4", "v4.0.0")
for name, obj in [("deployment-v3.yaml", dep_v3), ("deployment-v4.yaml", dep_v4), ("service.yaml", service), ("hpa.yaml", hpa)]:
    open(f"/tmp/l18/{name}", "w").write(yaml.safe_dump(obj, sort_keys=False))
c = dep_v4["spec"]["template"]["spec"]["containers"][0]
check(c["resources"]["limits"]["nvidia.com/gpu"] == 1 and "readinessProbe" in c and dep_v4["spec"]["strategy"]["rollingUpdate"]["maxUnavailable"] == 0, "manifest requests a GPU, has a readiness probe and a zero-unavailable rolling strategy")

# %% [markdown]
# ## Step 3 — Simulate the rolling update and count dropped requests
# *Why (pedagogy-first):* before touching a cluster, model what the controller does. Two v3 pods serve; a v4 pod is created (maxSurge 1) and receives traffic only after its readiness probe passes; then one v3 pod is terminated with a grace period draining in-flight requests; repeat. Count requests that hit a pod that was not ready. Then run the same simulation with `maxUnavailable: 1` and no readiness probe to see requests fail.
# %%
def simulate_rollout(readiness_probe=True, max_unavailable=0, load_time=6, ticks=60, req_per_tick=20, seed=0):
    """Returns dict(served, failed, timeline). Pods: dict name -> {'version','ready_at'}; traffic is spread over pods the controller considers ready."""
    # >>> SOLUTION discrete simulation: per tick, controller advances rollout; ready = tick>=ready_at if probe else True; route req_per_tick over 'ready' pods; a pod not truly loaded (tick<ready_at) fails its requests
    rng = np.random.default_rng(seed)
    pods = {"v3-a": {"version": "v3", "ready_at": -1}, "v3-b": {"version": "v3", "ready_at": -1}}; created = 0; served = failed = 0; timeline = []
    for t in range(ticks):
        # controller: keep 2 desired; surge 1; terminate old when a new one is ready (or immediately if maxUnavailable allows)
        n_v4 = sum(p["version"] == "v4" for p in pods.values()); n_v3 = sum(p["version"] == "v3" for p in pods.values())
        if n_v4 < 2 and len(pods) < 2 + 1: created += 1; pods[f"v4-{created}"] = {"version": "v4", "ready_at": t + load_time}
        for name in [n for n, p in pods.items() if p["version"] == "v3"]:
            new_ready = [n for n, p in pods.items() if p["version"] == "v4" and (t >= p["ready_at"])]
            if (max_unavailable >= 1 and n_v4 > 0) or (len(new_ready) > 2 - n_v3 - 1 + (0 if max_unavailable else 0) and len(pods) > 2):
                del pods[name]; break
        considered_ready = [n for n, p in pods.items() if (t >= p["ready_at"]) or not readiness_probe]
        if not considered_ready: failed += req_per_tick; continue
        for _ in range(req_per_tick):
            target = considered_ready[rng.integers(len(considered_ready))]
            if t >= pods[target]["ready_at"]: served += 1
            else: failed += 1
        timeline.append((t, sorted(pods)))
        if n_v4 == 2 and n_v3 == 0: pass
    return dict(served=served, failed=failed, final_pods=sorted(pods))
    # <<< SOLUTION
good = simulate_rollout(readiness_probe=True, max_unavailable=0); bad = simulate_rollout(readiness_probe=False, max_unavailable=1)
print("with readiness probe + maxUnavailable 0:", good); print("without probe + maxUnavailable 1:", bad)
check(good["failed"] == 0 and all(p.startswith("v4") for p in good["final_pods"]), "lossless rollout: zero failed requests, all pods on v4")
check(bad["failed"] > 0, "without readiness gating, requests fail during rollout")

# %% [markdown]
# ## Step 4 — A bad v4 never receives traffic
# *Why:* if v4's model fails to load, its readiness probe never passes; the controller keeps v3 serving and the rollout stalls (visible as `kubectl rollout status` not completing). Simulate a v4 that never becomes ready.
# %%
stalled = simulate_rollout(readiness_probe=True, max_unavailable=0, load_time=10**6)
print(stalled)
check(stalled["failed"] == 0 and any(p.startswith("v3") for p in stalled["final_pods"]), "bad v4 never serves; v3 keeps serving; rollout stalls safely")

# %% [markdown]
# ## Step 5 — On the cluster (AKS with a GPU node pool)
# *Why:* the same manifests, for real. Commands in the lab guide: build & push to ACR, `kubectl apply -f`, `kubectl set image` for v4, `kubectl rollout status`, and a request loop (`hey`/`k6` or the L03 harness) running throughout to count non-2xx responses.
# %%
if LAB_MODE == "GPU" and shutil.which("kubectl"):
    gpu_only("Apply /tmp/l18 manifests to the AKS GPU pool per lab guide; run the request loop during `kubectl set image`; record non-2xx count (must be 0).")
else:
    print("Artefacts written to /tmp/l18:", sorted(os.listdir("/tmp/l18")))
print("L18 complete." + ("" if LAB_MODE == "GPU" else " (SMOKE: Step 5 needs an AKS GPU node pool.)"))
