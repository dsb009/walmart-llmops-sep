const pptxgen=require('pptxgenjs'); const fs=require('fs'); const D=JSON.parse(fs.readFileSync('docs/_teach.json'));
const NAVY='21295C',DEEP='065A82',TEAL='1C7293',MINT='16A0A0',GOLD='E0A800',LIGHT='EAF3F6',GREY='F4F6F8',WHITE='FFFFFF',INK='1F2937',SAND='FFF4D6';
const HF='Cambria',BF='Calibri',W=10,H=5.625;
fs.mkdirSync('docs/decks',{recursive:true});
for(const day of D.days){
 const pres=new pptxgen(); pres.layout='LAYOUT_16x9'; pres.author='Aarvi Learning Solutions'; let n=0;
 const chrome=(s,light=true)=>{n++; s.background={color:light?WHITE:NAVY}; if(light) s.addShape(pres.shapes.RECTANGLE,{x:0,y:0,w:W,h:0.06,fill:{color:TEAL},line:{color:TEAL}});
  s.addText(`LLMOps for Advanced Practitioners · Day ${day.day} · Northfield Grocers edition`,{x:0.4,y:H-0.4,w:7,h:0.3,fontFace:BF,fontSize:9,color:light?'6B7280':'A9B7C6',isTextBox:true,margin:0});
  s.addText(String(n),{x:W-1,y:H-0.4,w:0.6,h:0.3,fontFace:BF,fontSize:9,color:light?'6B7280':'A9B7C6',align:'right',isTextBox:true,margin:0});};
 const heading=(s,t,sub)=>{s.addText(t,{x:0.4,y:0.22,w:W-0.8,h:0.55,fontFace:HF,fontSize:23,bold:true,color:NAVY,isTextBox:true,margin:0}); if(sub) s.addText(sub,{x:0.4,y:0.75,w:W-0.8,h:0.3,fontFace:BF,fontSize:12,italic:true,color:DEEP,isTextBox:true,margin:0});};
 const bullets=(s,items,x,y,w,h,fs=12.5)=>s.addText(items.map((t,i)=>({text:t,options:{bullet:true,breakLine:i<items.length-1,paraSpaceAfter:6}})),{x,y,w,h,fontFace:BF,fontSize:fs,color:INK,valign:'top',isTextBox:true});
 const box=(s,x,y,w,h,txt,o={})=>{s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x,y,w,h,fill:{color:o.fill||LIGHT},line:{color:o.line||TEAL,width:1},rectRadius:0.08}); s.addText(txt,{x:x+0.05,y,w:w-0.1,h,fontFace:BF,fontSize:o.fs||10,bold:o.bold,color:o.color||INK,align:'center',valign:'middle',isTextBox:true,margin:0});};
 const arrow=(s,x1,y,x2)=>s.addShape(pres.shapes.LINE,{x:x1,y,w:x2-x1,h:0.01,line:{color:TEAL,width:1.5,endArrowType:'triangle'}});
 const table=(s,head,rows,colW,y=1.1,fs=10)=>{const tr=[head.map(h=>({text:h,options:{bold:true,color:WHITE,fill:{color:DEEP},fontFace:BF,fontSize:fs+0.5}}))]; rows.forEach((r,ri)=>tr.push(r.map(c=>({text:String(c),options:{fontFace:BF,fontSize:fs,color:INK,fill:{color:ri%2?GREY:WHITE}}})))); s.addTable(tr,{x:0.4,y,w:W-0.8,colW,border:{type:'solid',pt:0.5,color:'D1D5DB'},margin:0.05});};
 const dark=(kicker,title,sub,notes)=>{const s=pres.addSlide(); chrome(s,false); s.addShape(pres.shapes.RECTANGLE,{x:0,y:0,w:0.18,h:H,fill:{color:GOLD},line:{color:GOLD}});
  s.addText(kicker,{x:0.6,y:0.9,w:8.8,h:0.35,fontFace:BF,fontSize:12,bold:true,color:MINT,isTextBox:true,margin:0}); s.addText(title,{x:0.6,y:1.35,w:8.8,h:1.4,fontFace:HF,fontSize:32,bold:true,color:WHITE,isTextBox:true,margin:0,valign:'top'});
  s.addText(sub,{x:0.6,y:2.9,w:8.8,h:1.2,fontFace:BF,fontSize:15,italic:true,color:'CADCFC',isTextBox:true,margin:0}); s.addNotes(notes); return s;};
 // Title
 dark(`DAY ${day.day} OF 5 · ADVANCED TRACK`,`Day ${day.day}: ${day.title}`,`Objectives ${day.objectives.join(', ')} · Labs ${day.labs.join(', ')}\n${D.scenario}`,`Day ${day.day} opener. Objectives covered: ${day.objectives.join(', ')}. Labs: ${day.labs.join(', ')}. Every TEACH block has the same four slides — definitions, how it works, Northfield application, references — followed by the LAB BRIEFING generated from the lab package, so slide numbers and lab numbers always agree. Set the day's arc in one sentence and move on. Time: 2 minutes.`);
 // Agenda
 {const s=pres.addSlide(); chrome(s); heading(s,`Day ${day.day} agenda`);
  const rows=[]; for(const o of day.objectives){rows.push([`TEACH · Objective ${o}`,D.obj[o].title,'35–45 min']);} for(const l of day.labs){const L=D.labs[l]; rows.push([`LAB · ${l}`,L.title,`${L.hours} h`]);}
  table(s,['Block','Topic','Time'],rows,[1.8,6.2,1.2],1.05,10.5);
  s.addNotes('Agenda. TEACH blocks precede their labs. Announce the compute for the day (which labs need the GPU cluster / serverless GPU vs CPU) so participants attach the right compute before the briefing. Time: 2 minutes.');}
 for(const o of day.objectives){ const T=D.obj[o];
  dark(`TEACH · OBJECTIVE ${o}`,T.title,'Definitions → how it works → Northfield Grocers application → references → lab briefing',`Section divider for objective ${o}: ${T.title}. Four teaching slides follow. Time: 1 minute.`);
  // definitions
  {const s=pres.addSlide(); chrome(s); heading(s,`Objective ${o} · Definitions`,`${T.title} — terms used in the lab, defined before the code`);
   table(s,['Term','Definition'],T.defs.map(d=>[d[0],d[1]]),[2.3,6.9],1.1,T.defs.length>6?9:10);
   s.addNotes(`Definitions for objective ${o}. Read each term once, in the audience's words if possible, and point to where it appears in the lab notebook. These are the terms the pre/post test questions use. ${T.defs.map(d=>d[0]+': '+d[1]).join(' | ')} Time: 5 minutes.`);}
  // how it works
  {const s=pres.addSlide(); chrome(s); heading(s,`Objective ${o} · How it works`,T.title);
   const n=T.flow.length, gap=0.25, bw=(W-0.8-gap*(n-1))/n;
   T.flow.forEach((t,i)=>{const x=0.4+i*(bw+gap); box(s,x,1.15,bw,1.0,t,{fs:9.5,fill:i%2?GREY:LIGHT}); if(i<n-1) arrow(s,x+bw,1.65,x+bw+gap);});
   bullets(s,T.ideas,0.5,2.4,9,2.4,12.5);
   s.addNotes(`Mechanics for objective ${o}. Walk the flow left to right, then the four key ideas — each idea is something the lab asserts with a check(). ${T.ideas.join(' | ')} Time: 8 minutes.`);}
  // retail application
  {const s=pres.addSlide(); chrome(s); heading(s,`Objective ${o} · Northfield Grocers application`,`${T.title} · fictional chain, 420 stores, 38,000 SKUs`);
   s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x:0.4,y:1.15,w:9.2,h:2.3,fill:{color:SAND},line:{color:SAND},rectRadius:0.1});
   s.addText(T.retail,{x:0.6,y:1.25,w:8.8,h:2.1,fontFace:BF,fontSize:12.5,color:INK,isTextBox:true,margin:0,valign:'top'});
   s.addText('Industry references',{x:0.4,y:3.6,w:9.2,h:0.3,fontFace:HF,fontSize:13,bold:true,color:DEEP,isTextBox:true,margin:0});
   bullets(s,T.refs,0.5,3.9,9,1.2,10.5);
   s.addNotes(`Application for objective ${o}. The Northfield scenario is fictional but every detail is a real supermarket constraint (safety facts, seasonality, volume, offline stores). References are primary sources — papers and vendor docs; verify URLs before distributing. Ask: what is the equivalent in your own team? Time: 6 minutes.`);}
 }
 for(const l of day.labs){ const L=D.labs[l];
  const s=pres.addSlide(); chrome(s); heading(s,`Lab briefing · ${l}`,L.title);
  s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x:0.4,y:1.05,w:5.6,h:3.9,fill:{color:LIGHT},line:{color:LIGHT},rectRadius:0.1});
  s.addText([{text:'Summary\n',options:{bold:true,color:DEEP}},{text:L.summary+'\n\n'},{text:'Done means\n',options:{bold:true,color:DEEP}},{text:L.done}],{x:0.6,y:1.15,w:5.2,h:3.7,fontFace:BF,fontSize:11,color:INK,isTextBox:true,margin:0,valign:'top'});
  s.addShape(pres.shapes.ROUNDED_RECTANGLE,{x:6.2,y:1.05,w:3.4,h:3.9,fill:{color:GREY},line:{color:GREY},rectRadius:0.1});
  const meta=[`Compute: ${L.sku}`,`Duration: ${L.hours} h (GPU ≈ ${L.gpu_hours} h)`,`Files: labs/${l}/${l}_lab.ipynb`,...(L.steps.length?['Steps:',...L.steps.map(x=>'  '+x.replace(/ — .*/,' — '+x.split(' — ')[1].slice(0,38)))]:[])];
  s.addText(meta.map((t,i)=>({text:t,options:{breakLine:i<meta.length-1,fontSize:t.startsWith('  ')?8.5:10,bold:!t.startsWith('  ')}})),{x:6.35,y:1.15,w:3.15,h:3.7,fontFace:BF,color:INK,isTextBox:true,margin:0,valign:'top'});
  s.addNotes(`Lab briefing ${l}. Read the summary and the done-means check aloud; confirm everyone is attached to the right compute; remind them the starter stops at each TODO with a hint and that every check() prints PASS or halts. Retail use cases: ${(L.use_cases||[]).join('; ')}. Steps: ${L.steps.join('; ')}. Time: 5 minutes, then the lab.`);}
 // Close
 dark(`DAY ${day.day} · CLOSE`,'Review and tomorrow','One team demos its lab result · common errors named · tomorrow previewed · pre/post-test items for today\'s objectives',`Close of day ${day.day}. One team demos; name the two or three errors most participants hit; preview day ${day.day+1 <=5 ? day.day+1 : 'wrap-up'}. Point to the post-test questions that map to today's objectives. Time: 10 minutes.`);
 pres.writeFile({fileName:`docs/decks/LLMOps_Day${day.day}_Northfield.pptx`}).then(f=>console.log('wrote',f));
}
